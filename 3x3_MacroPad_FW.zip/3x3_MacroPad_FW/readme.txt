Step 1. Plug in MacroPad. A drive called CIRCUITPY should appear.
Step 2. Delete All Items within CircuitPy Drive and replace with the contents of this Folder (Please ensure you UNZIP the package)
[OPTIONAL ]Step 3. Modify code within code.py to your liking.

Online GUI now available @ https://respawnin.github.io/3x3MacroPadGUI/