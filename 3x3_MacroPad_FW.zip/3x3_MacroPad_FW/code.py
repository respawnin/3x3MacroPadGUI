# GETTING STARTED WITH KMK
# https://github.com/KMKfw/kmk_firmware/blob/main/docs/en/Getting_Started.md
# KEYCODE REFERENCE:
# https://github.com/KMKfw/kmk_firmware/blob/main/docs/en/keycodes.md

# MAIN PROJECT PAGE:
# https://github.com/KMKfw/kmk_firmware
#================================================================
# CODE written for 3x3 MacroPad running on RP2040
# Code based on latest KMK Firmware as of May 2025
#================================================================
# This is a working demo code to test a 3x3 Macropad in the form of a numpad.
# Online GUI Macropad editor available at: https://respawnin.github.io/3x3MacroPadGUI/
#================================================================
#================================================================
import board

from kmk.kmk_keyboard import KMKKeyboard
from kmk.keys import KC
from kmk.scanners import DiodeOrientation
from kmk.modules.macros import Macros, UnicodeModeMacOS
from kmk.modules.macros import Delay, Press, Release, Tap

keyboard = KMKKeyboard()

macros = Macros()
keyboard.modules.append(macros)


keyboard.col_pins = (board.GP3, board.GP4, board.GP5,)
keyboard.row_pins = (board.GP8, board.GP7, board.GP6,)
keyboard.diode_orientation = DiodeOrientation.ROW2COL
#================================================================
#================================================================


#================================================================
#numpad keymap for cross platform testing of individual keys

keyboard.keymap = [
    [
        KC.KP_7,  KC.KP_8,  KC.KP_9, 
        KC.KP_4,  KC.KP_5,  KC.KP_6, 
        KC.KP_1,  KC.KP_2,  KC.KP_3, 
    ],

]



#================================================================
#================================================================

if __name__ == '__main__':
    keyboard.go()
    